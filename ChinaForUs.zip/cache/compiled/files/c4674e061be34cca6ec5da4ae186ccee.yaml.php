<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/plugins/adminstyles.yaml',
    'modified' => 1572266473,
    'data' => [
        'enabled' => true,
        'preview' => false,
        'styles' => [
            0 => 'grav_admin',
            1 => 'metal',
            2 => 'hoth',
            3 => 'light',
            4 => 'stark_contrast',
            5 => 'dark_ocean',
            6 => 'wine',
            7 => 'beach',
            8 => 'muted_beach',
            9 => 'sunrise',
            10 => 'navy_sunrise',
            11 => 'tan',
            12 => 'grey',
            13 => 'gold',
            14 => 'arctic',
            15 => 'amber',
            16 => 'antique'
        ],
        'current' => 'navy_sunrise',
        'type' => 'radioimage',
        'custom_styles' => [
            0 => [
                'name' => 'ChinaForUsAdmin',
                'main' => '#2a3fe0',
                'secondary' => '#b57474',
                'main_alt' => '#551fa6',
                'secondary_alt' => '#ffffff',
                'text' => '#ffffff',
                'text_alt' => '#c28282',
                'background' => '#5e1515'
            ]
        ]
    ]
];
