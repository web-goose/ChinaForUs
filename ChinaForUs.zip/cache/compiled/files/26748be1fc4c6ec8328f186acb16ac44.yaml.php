<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/streams.yaml',
    'modified' => 1572033294,
    'data' => [
        
    ]
];
