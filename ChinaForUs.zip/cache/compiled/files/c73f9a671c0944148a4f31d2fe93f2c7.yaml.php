<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://pagination/pagination.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'delta' => 0
    ]
];
