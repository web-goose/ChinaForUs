<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://core-service-manager/core-service-manager.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'override_admin_twigs' => true,
        'show_samples' => false
    ]
];
