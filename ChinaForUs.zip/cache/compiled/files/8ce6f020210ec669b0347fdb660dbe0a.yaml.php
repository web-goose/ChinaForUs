<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/themes/chinaforus/blueprints.yaml',
    'modified' => 1572033294,
    'data' => [
        'name' => 'ChinaForUs',
        'version' => '1.0.0',
        'icon' => 'empire',
        'author' => [
            'name' => 'WebGoose'
        ],
        'license' => 'MIT'
    ]
];
