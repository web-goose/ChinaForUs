<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/plugins/admin-power-tools.yaml',
    'modified' => 1572267822,
    'data' => [
        'enabled' => true,
        'edit_page_enabled' => false,
        'edit_section_enabled' => false,
        'edit_section_syntax_enabled' => true,
        'add_page_enabled' => true,
        'reports_enabled' => false,
        'child_reordering_enabled' => true,
        'child_reordering_immediate' => true,
        'move_page_enabled' => false,
        'rename_page_enabled' => false
    ]
];
