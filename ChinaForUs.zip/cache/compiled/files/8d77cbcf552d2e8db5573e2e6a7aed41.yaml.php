<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://devtools/devtools.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true
    ]
];
