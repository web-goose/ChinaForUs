<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/site.yaml',
    'modified' => 1572270719,
    'data' => [
        'title' => 'CHINAFORUS',
        'default_lang' => 'ru',
        'author' => [
            'name' => 'https://webgoose.ru',
            'email' => 'john@example.com'
        ],
        'taxonomies' => [
            0 => 'category',
            1 => 'tag'
        ],
        'metadata' => [
            'description' => 'Grav is an easy to use, yet powerful, open source flat-file CMS',
            'keywords' => 'wewe'
        ],
        'summary' => [
            'enabled' => true,
            'format' => 'short',
            'size' => 300,
            'delimiter' => '==='
        ],
        'blog' => [
            'route' => '/blog'
        ],
        'team' => [
            0 => [
                'name' => 'Владимир',
                'role' => 'Founder & Art Director'
            ],
            1 => [
                'name' => 'Дмитрий',
                'role' => 'Design Director'
            ],
            2 => [
                'name' => 'Алена',
                'role' => 'Customers Suppport'
            ]
        ]
    ]
];
