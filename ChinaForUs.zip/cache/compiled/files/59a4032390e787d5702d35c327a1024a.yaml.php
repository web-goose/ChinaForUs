<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/plugins/autoseo/autoseo.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'description' => [
            'enabled' => true,
            'length' => 30
        ],
        'keywords' => [
            'enabled' => true,
            'length' => 20
        ],
        'facebook' => [
            'enabled' => true
        ],
        'twitter' => [
            'enabled' => true
        ]
    ]
];
