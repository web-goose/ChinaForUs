<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/plugins/add-page-by-form.yaml',
    'modified' => 1572266062,
    'data' => [
        'enabled' => true,
        'date_display_format' => 'd-m-Y g:ia',
        'default_title' => 'My New Page',
        'default_content' => 'No content.',
        'overwrite_mode' => false,
        'include_username' => false,
        'auto_taxonomy_types' => false
    ]
];
