<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/plugins/admin-addon-user-manager/admin-addon-user-manager.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'default_list_style' => 'list',
        'pagination' => [
            'per_page' => 20
        ]
    ]
];
