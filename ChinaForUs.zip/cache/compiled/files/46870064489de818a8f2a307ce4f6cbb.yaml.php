<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/plugins/admin-addon-user-manager.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'default_list_style' => 'grid',
        'pagination' => [
            'per_page' => '20'
        ]
    ]
];
