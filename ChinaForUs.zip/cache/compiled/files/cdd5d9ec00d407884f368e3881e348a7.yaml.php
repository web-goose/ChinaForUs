<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/plugins/admin-power-tools/admin-power-tools.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'edit_page_enabled' => true,
        'edit_section_enabled' => true,
        'edit_section_syntax_enabled' => true,
        'add_page_enabled' => true,
        'reports_enabled' => true,
        'child_reordering_enabled' => true,
        'child_reordering_immediate' => true,
        'move_page_enabled' => false,
        'rename_page_enabled' => false
    ]
];
