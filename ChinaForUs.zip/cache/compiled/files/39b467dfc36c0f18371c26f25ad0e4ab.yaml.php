<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/plugins/minify-html/minify-html.yaml',
    'modified' => 1572267988,
    'data' => [
        'enabled' => true,
        'cache' => false,
        'mode' => 'default'
    ]
];
