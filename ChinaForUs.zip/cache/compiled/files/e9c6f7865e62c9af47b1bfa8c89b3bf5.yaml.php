<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://chinaforus/chinaforus.yaml',
    'modified' => 1572033294,
    'data' => [
        'enabled' => true,
        'production-mode' => true,
        'blog-page' => '/blog'
    ]
];
