<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/sites/ChinaForUs/user/config/backups.yaml',
    'modified' => 1572033294,
    'data' => [
        
    ]
];
