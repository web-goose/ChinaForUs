<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* faq.html.twig */
class __TwigTemplate_f8821ddad16e6db9e166b2df7c4c82cac75757b34f757a09b0b1cea763bb1b30 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 3
        if ($this->getAttribute($this->getAttribute(($context["page"] ?? null), "header", []), "isNotIndex", [])) {
        }
        // line 1
        $this->parent = $this->loadTemplate("partials/base.html.twig", "faq.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        // line 5
        echo "        ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
        ";
        // line 6
        $this->getAttribute(($context["assets"] ?? null), "addCss", [0 => "theme://css/other-page.css", 1 => 101], "method");
        // line 7
        echo "    ";
    }

    // line 10
    public function block_content($context, array $blocks = [])
    {
        // line 11
        echo "    ";
        $this->loadTemplate("partials/faq.html.twig", "faq.html.twig", 11)->display($context);
    }

    public function getTemplateName()
    {
        return "faq.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 11,  58 => 10,  54 => 7,  52 => 6,  47 => 5,  44 => 4,  39 => 1,  36 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"partials/base.html.twig\" %}

{% if page.header.isNotIndex %}
    {% block stylesheets %}
        {{ parent() }}
        {% do assets.addCss('theme://css/other-page.css', 101) %}
    {% endblock %}
{% endif %}

{% block content %}
    {% include 'partials/faq.html.twig' %}
{% endblock %}
", "faq.html.twig", "/var/www/sites/ChinaForUs/user/themes/chinaforus/templates/faq.html.twig");
    }
}
