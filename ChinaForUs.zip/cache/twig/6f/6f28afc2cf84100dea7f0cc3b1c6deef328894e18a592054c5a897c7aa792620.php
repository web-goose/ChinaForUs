<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/services/inspection.html.twig */
class __TwigTemplate_0f2f09f318da28463b2530a31dc7866ff48b6cc4c7364a90a5fcb40a8f4fd47c extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<section class=\"inspection uid-1\">
    <div class=\"container\">
        <div class=\"row items\">
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"section-title\">Каким бы не был надежным поставщик, всегда требуется инспекция качества и
                                                                                                    функционала до производства, во время производства и проверка уже готового продукта. Инспекция
                                                                                                    разделяется на несколько видов:
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Аудит (проверка) поставщика</h3>
                        <p>Инспекция фабрики до производства товара. Данный вид инспекции предназначен для оценки
                                                                                                                                            поставщика, проверки документов, производственных мощностей, оборудования и т.д.
                                                                                                                
                                                                                                                                            Цель данного вида инспекции – установить, является ли поставщик производителем товара или
                                                                                                                                            посредником, имеет ли соответствующую регистрацию и документы, какие у него производственные
                                                                                                                                            площади и в каком состоянии они находятся, какое оборудование используется, количество
                                                                                                                                            персонал, его компетентность и прочее, все это имеет важное значение еще до начала работы и
                                                                                                                                            позволяет избежать ошибок в дальнейшем.</p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"";
        // line 24
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/inspection/1.jpg");
        echo "\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"";
        // line 31
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/inspection/2.jpg");
        echo "\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Инспекция во время производста вашего товара</h3>
                        <p>Позволяет понять, соответствует ли производимый товар требованиям, выявить проблемы и внести
                                                                                                                                            изменения в процессе производства.
                                                                                                                
                                                                                                                                            Цель данного вида инспекции – своевременно выявить проблемы при производстве товара, оценить
                                                                                                                                            качество компонентов, соответствие оборудования, квалификацию персонала и других факторы.
                                                                                                                                            Если требуется, внести изменения и/или дополнения.</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Инспекция готовой партии товара</h3>
                        <p>Одна из важных задач продавца, это недопущение (сведение к минимуму) попадания некачественной
                                                                                                                                            или бракованной продукции на склады Амазон и конечному потребителю. Поэтому необходимо
                                                                                                                                            регулярно проверять качество товара до отгрузки.
                                                                                                                
                                                                                                                                            Инспекция разделяется на 2 типа- выборочная (рандомная), позволяющая выявить процент брака и
                                                                                                                                            полная (выбраковка) всей партии товара.
                                                                                                                
                                                                                                                                            Цель – контроль заявленного качества, выявление брака и исключение замены (удешевления)
                                                                                                                                            используемых материалов.</p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"";
        // line 59
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/inspection/3.jpg");
        echo "\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"section-title\">
                    Так, с помощью инспекции можно понять легальность и возможности поставщика, своевременно выявить
                                                                                                    проблемы при производстве товара, а также
                    <b>контролировать</b>
                    качество уже готового товара.
                </div>
            </div>
        </div>
    </div>
    <div class=\"col-12 text-center\">
        <button class=\"main-btn\">Заполнить заявку на услугу</button>
    </div>
</section>
";
    }

    public function getTemplateName()
    {
        return "partials/services/inspection.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 59,  65 => 31,  55 => 24,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"inspection uid-1\">
    <div class=\"container\">
        <div class=\"row items\">
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"section-title\">Каким бы не был надежным поставщик, всегда требуется инспекция качества и
                                                                                                    функционала до производства, во время производства и проверка уже готового продукта. Инспекция
                                                                                                    разделяется на несколько видов:
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Аудит (проверка) поставщика</h3>
                        <p>Инспекция фабрики до производства товара. Данный вид инспекции предназначен для оценки
                                                                                                                                            поставщика, проверки документов, производственных мощностей, оборудования и т.д.
                                                                                                                
                                                                                                                                            Цель данного вида инспекции – установить, является ли поставщик производителем товара или
                                                                                                                                            посредником, имеет ли соответствующую регистрацию и документы, какие у него производственные
                                                                                                                                            площади и в каком состоянии они находятся, какое оборудование используется, количество
                                                                                                                                            персонал, его компетентность и прочее, все это имеет важное значение еще до начала работы и
                                                                                                                                            позволяет избежать ошибок в дальнейшем.</p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"{{ url('theme://img/services/img/inspection/1.jpg') }}\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"{{ url('theme://img/services/img/inspection/2.jpg') }}\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Инспекция во время производста вашего товара</h3>
                        <p>Позволяет понять, соответствует ли производимый товар требованиям, выявить проблемы и внести
                                                                                                                                            изменения в процессе производства.
                                                                                                                
                                                                                                                                            Цель данного вида инспекции – своевременно выявить проблемы при производстве товара, оценить
                                                                                                                                            качество компонентов, соответствие оборудования, квалификацию персонала и других факторы.
                                                                                                                                            Если требуется, внести изменения и/или дополнения.</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <h3>Инспекция готовой партии товара</h3>
                        <p>Одна из важных задач продавца, это недопущение (сведение к минимуму) попадания некачественной
                                                                                                                                            или бракованной продукции на склады Амазон и конечному потребителю. Поэтому необходимо
                                                                                                                                            регулярно проверять качество товара до отгрузки.
                                                                                                                
                                                                                                                                            Инспекция разделяется на 2 типа- выборочная (рандомная), позволяющая выявить процент брака и
                                                                                                                                            полная (выбраковка) всей партии товара.
                                                                                                                
                                                                                                                                            Цель – контроль заявленного качества, выявление брака и исключение замены (удешевления)
                                                                                                                                            используемых материалов.</p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"{{ url('theme://img/services/img/inspection/3.jpg') }}\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"section-title\">
                    Так, с помощью инспекции можно понять легальность и возможности поставщика, своевременно выявить
                                                                                                    проблемы при производстве товара, а также
                    <b>контролировать</b>
                    качество уже готового товара.
                </div>
            </div>
        </div>
    </div>
    <div class=\"col-12 text-center\">
        <button class=\"main-btn\">Заполнить заявку на услугу</button>
    </div>
</section>
", "partials/services/inspection.html.twig", "/var/www/sites/ChinaForUs/user/themes/chinaforus/templates/partials/services/inspection.html.twig");
    }
}
