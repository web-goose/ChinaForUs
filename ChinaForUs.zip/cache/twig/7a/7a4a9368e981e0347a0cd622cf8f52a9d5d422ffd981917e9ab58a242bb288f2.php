<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/services/uslugi-sklada.html.twig */
class __TwigTemplate_2b2a45980dc574a089154d2534967a606ab1c4f12052d24724e98e24b05ec835 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<section class=\"uslugi-sklada uid-1\">
    <div class=\"container\">
        <div class=\"row items\">
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Благодаря большому опыту работы с заказами и доставкой товаров, наша команда с
                                                        профессионализмом возьмет на себя часть рутинных задач, отнимающих много сил и времени,
                                                        которые теперь вы сможете потратить на новые идеи и продвижение ваших товаров.
                        </p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"";
        // line 13
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/uslugi-sklada/1.jpg");
        echo "\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"";
        // line 20
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/uslugi-sklada/2.jpg");
        echo "\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Мы предлагаем индивидуальный подход для ваших потребностей в упаковке и подготовке для
                                                        продажи на
                            <b>Amazon</b>,
                            <b>eBay</b>
                            и других площадках. Наши сотрудники будут работать как в
                                                        соответствии с вашими конкретными требованиями, так и предлагать решения, исходя из своего
                                                        опыта.</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Операторы ответят на ваши вопросы, а склад выполнит любые задачи, такие, как:<br/>
                            - Сборка товаров<br/>
                            - Формирование наборов<br/>
                            - Дизайн макета и изготовление упаковки<br/>
                            - Упаковка<br/>
                            - Проверка партии на брак, комплектность
                        </p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"";
        // line 45
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/uslugi-sklada/3.jpg");
        echo "\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"";
        // line 52
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->urlFunc("theme://img/services/img/uslugi-sklada/4.jpg");
        echo "\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>
                            - Изготовление и поклейка
                            <b>FNSKU</b>
                            и других штрих-кодов различных стандартов<br/>
                            - Подготовка к отправке в соответствии со стандартами
                            <b>Amazon</b>,
                            <b>Ebay</b>,
                            <b>Etsy</b>
                            и других площадок<br/>
                            - Усиление транспортировочных коробок<br/>
                            - Другие нестандартные задачи</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <button class=\"main-btn\">Заполнить заявку на услугу</button>
            </div>
        </div>
    </div>
</section>
";
    }

    public function getTemplateName()
    {
        return "partials/services/uslugi-sklada.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 52,  82 => 45,  54 => 20,  44 => 13,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"uslugi-sklada uid-1\">
    <div class=\"container\">
        <div class=\"row items\">
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Благодаря большому опыту работы с заказами и доставкой товаров, наша команда с
                                                        профессионализмом возьмет на себя часть рутинных задач, отнимающих много сил и времени,
                                                        которые теперь вы сможете потратить на новые идеи и продвижение ваших товаров.
                        </p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"{{ url('theme://img/services/img/uslugi-sklada/1.jpg') }}\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"{{ url('theme://img/services/img/uslugi-sklada/2.jpg') }}\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Мы предлагаем индивидуальный подход для ваших потребностей в упаковке и подготовке для
                                                        продажи на
                            <b>Amazon</b>,
                            <b>eBay</b>
                            и других площадках. Наши сотрудники будут работать как в
                                                        соответствии с вашими конкретными требованиями, так и предлагать решения, исходя из своего
                                                        опыта.</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>Операторы ответят на ваши вопросы, а склад выполнит любые задачи, такие, как:<br/>
                            - Сборка товаров<br/>
                            - Формирование наборов<br/>
                            - Дизайн макета и изготовление упаковки<br/>
                            - Упаковка<br/>
                            - Проверка партии на брак, комплектность
                        </p>
                    </div>
                    <div class=\"col-md-6 col-12\">
                        <img src=\"{{ url('theme://img/services/img/uslugi-sklada/3.jpg') }}\" alt=\"1\">
                    </div>
                </div>
            </div>
            <div class=\"col-12 item wow fadeIn\" data-wow-delay=\".3s\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-12 order-md-0 order-1\">
                        <img src=\"{{ url('theme://img/services/img/uslugi-sklada/4.jpg') }}\" alt=\"2\">
                    </div>
                    <div class=\"col-md-6 col-12 item-info\">
                        <p>
                            - Изготовление и поклейка
                            <b>FNSKU</b>
                            и других штрих-кодов различных стандартов<br/>
                            - Подготовка к отправке в соответствии со стандартами
                            <b>Amazon</b>,
                            <b>Ebay</b>,
                            <b>Etsy</b>
                            и других площадок<br/>
                            - Усиление транспортировочных коробок<br/>
                            - Другие нестандартные задачи</p>
                    </div>
                </div>
            </div>
            <div class=\"col-12 text-center wow fadeIn\" data-wow-delay=\".3s\">
                <button class=\"main-btn\">Заполнить заявку на услугу</button>
            </div>
        </div>
    </div>
</section>
", "partials/services/uslugi-sklada.html.twig", "/var/www/sites/ChinaForUs/user/themes/chinaforus/templates/partials/services/uslugi-sklada.html.twig");
    }
}
